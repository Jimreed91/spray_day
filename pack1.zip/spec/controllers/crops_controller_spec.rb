# require 'rails_helper'

# RSpec.describe CropsController, '#create' do

#   context 'when the crop details are invalid' do
#     it 're-renders the form' do
#       post :create, crop: build(:crop, name: nil)
#       expect(response).to render_template :new
#     end
#   end
# end
