# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'pages/main.html.erb', type: :view do
  pending
end
