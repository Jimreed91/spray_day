# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Farm, type: :model do
  pending
end
