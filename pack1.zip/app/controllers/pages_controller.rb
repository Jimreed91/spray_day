# frozen_string_literal: true

# Top level doc
class PagesController < ApplicationController
end
