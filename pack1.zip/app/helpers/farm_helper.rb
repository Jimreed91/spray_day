# frozen_string_literal: true

# Top level doc
module FarmHelper
end
