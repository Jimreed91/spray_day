module SprayerHelper
end
